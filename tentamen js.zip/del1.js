let mevar = "går att ändra på";


const PERMANENT = "hello world!";